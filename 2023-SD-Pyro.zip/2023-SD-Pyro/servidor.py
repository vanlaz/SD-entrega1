class Servidor(object):
    def __init__(self):
        self.clientes = []
        self.leiloes = []

    # retorna lista de motoristas
    def leiloes_ativos(self):
        return self.leiloes

    # invoca lista de viagens cadastradas conforme o tipo de usuario
    def consulta_usuaria(self, id_user, tp_user):
        if tp_user == '1':
            lista_de_usuarias = self.passageira
        else:
            lista_de_usuarias = self.motorista
        for usuaria in lista_de_usuarias:
            if str(usuaria[0]) == id_user:
                return usuaria

    def consulta(self, origem, destino, data, tp_user):
        lista_compativeis = []
        if tp_user == '1':
            lista_de_viagens = self.procura_por_passageira
        else:
            lista_de_viagens = self.procura_por_carona
        for viagens in lista_de_viagens:
            if viagens[2] == origem and viagens[3] == destino and viagens[4] == data:
                usuaria_compativel = self.consulta_usuaria(viagens[1], tp_user)
                lista_compativeis.append([usuaria_compativel, viagens])
        return lista_compativeis

    def cadastro(self, nome_cliente, ref_cliente, public_key):
        if (tp_user == 1):
            id_user = (len(self.motorista) + 1)
            #define a idUser de motorista como o proximo numero disponivel e adiciona no array de motoristas
            self.motorista.append([id_user, nome, telefone])
            return id_user
        else:
            id_user = (len(self.passageira) + 1)
            #define a idUser de passageiro como o proximo numero disponivel e adiciona no array de passageiros
            self.passageira.append([id_user, nome, telefone])
            return id_user

    def notifica_passageira(self, origem, destino, data):
        for viagens in self.procura_por_carona:
            if viagens[2] == data and viagens[0] == origem and viagens[1] == destino:
                print(f'Passageira, vooê tem uma viagem para {destino} compatível')
                print(f'Motorista, vooê tem uma viagem para {destino} compatível')

    def notifica_motorista(self, origem, destino, data):
        for viagens in self.procura_por_passageira:
            if viagens[2] == data and viagens[0] == origem and viagens[1] == destino:
                print(f'Motorista, vooê tem uma viagem para {destino} compatível')
                print(f'Passageira, vooê tem uma viagem para {destino} compatível')

    # cadastra interesse do passageiro em carona
    def interesse_em_carona(self, origem, destino, data, id_user):
        # cria id unica para cada carona e retira caracteres especiais
        id_corrida = str(datetime.now()).replace(":", "").replace("-", "").replace(".", "").replace(" ", "")
        self.procura_por_carona.append([origem, destino, data, id_corrida, id_user])
        self.notifica_motorista(origem, destino, data)
        return id_corrida

    # cadastra interesse do motorista em oferecer carona
    def interesse_em_passageira(self, origem, destino, data, id_user):
        # cria id unica para cada viagem e retira caracteres especiais
        id_corrida = str(datetime.now()).replace(":", "").replace("-", "").replace(".", "").replace(" ", "")
        self.procura_por_passageira.append([origem, destino, data, id_corrida, id_user])
        self.notifica_passageira(origem, destino, data)
        return id_corrida

    # cancela subscription do motorista para notificacoes de possiveis passageiros
    def cancelar_interesse_em_passageira(self, id_corrida):
        for i in range(0, len(self.procura_por_passageira)):
            if self.procura_por_passageira[i][0] == id_corrida:
                self.procura_por_passageira.pop(i)

    # cancela subscription do passageiro para notificacoes de possiveis viagens
    def cancelar_interesse_em_carona(self, id_corrida):
        for i in range(0, len(self.procura_por_carona)):
            if self.procura_por_carona[i][0] == id_corrida:
                self.procura_por_carona.pop(i)


def main():
    Pyro4.Daemon.serveSimple(
        {
            Servidor: "servidor.carona"
        },
        ns=True)


if __name__ == "__main__":
    main()
