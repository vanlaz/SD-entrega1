# Classe Leilão, com preço, tempo e comprador atual, além da função de novo lance
# Retornos:
# 0: Sucesso
# 1: Erro desconhecido
# 2: Valor invalido
# 3: Objeto finalizado


class Leilao:

    def __init__(self, codigo, nome_produto, descricao_produto, preco_inicial, tempo):

        self.codigo = codigo
        self.nome_produto = nome_produto
        self.descricao_produto = descricao_produto
        self.valor_atual = preco_inicial
        self.tempo = tempo
        self.lances = []
        self.ativo = True

    def valor_atual(self):
        return self.valor_atual

    def comprador_atual(self):
        return self.comprador_atual

    def realizar_lance(self, valor, comprador):
        if self.tempo <= 0:
            print('Leilão finalizado')

        elif valor < self.valor_atual():
            print('Lance inválido')

        else:
            self.valor_atual = valor
            self.comprador_atual = comprador
            print(f'Lance realizado para o produto' + nome_produto + '!')

    def tick_tempo(self):
        if self.tempo > 0:
            self.tempo = self.tempo - 1

        else:
            print('Leilão finalizado')
