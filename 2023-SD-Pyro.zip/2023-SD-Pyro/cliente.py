from __future__ import print_function
import sys
import Pyro4.util
import json

sys.excepthook = Pyro4.util.excepthook

servidor = Pyro4.Proxy("PYRONAME:servidor.carona")



# cadastra a carona, verifica a lista de interesse para viagens cadastradas por motoristas,
# inclui a corrida na lista de interesse
def consulta(id_user):
    if(not(id_user)):
        print("Antes de agendar a viagem, precisamos de um cadastro!\n")
        id_user = cadastro()
    destino = input("Para onde deseja ir? ").strip()
    origem = input("Aonde está? ").strip()
    data = input("Quando deseja ir? ").strip()
    if origem and destino and data:
        res_consulta = servidor.consulta(destino, origem, data, 0)
        # Registro de interesse em eventos (1,1)
        id_corrida = servidor.interesse_em_carona(destino, origem, data, id_user)
        print(f'id corrida passageira: {id_corrida}')
        if not res_consulta:
            adicionar_a_lista = input(
                "Não encontrei nada deseja adicionar a sua lista de interesse? 1 - SIM/ 0 - NÃO\n").strip()
            if adicionar_a_lista == '0':
                print('Tudo bem! Nos vemos na próxima\n')
                servidor.cancelar_interesse_em_carona(id_corrida)
        else:
            servidor.cancelar_interesse_em_carona(id_corrida)
            print(res_consulta)

#cadastro de usuario
def cadastro ():
    print("Novo por aqui? Cadastre-se\n")
    nome = input("Qual seu nome? ").strip()
    telefone = input("Certo! \n Qual seu telefone?").strip()
    if nome and telefone:
        id_user = servidor.cadastro(nome, telefone, 0) #O ultimo campo - se 1 motorista, se 0 passageiro
        print(id_user)
    return id_user

# remocao da lista de interesse
def remove_interesse():
    remover = input("Digite o número da viagem que deseja remover").strip()
    servidor.cancelar_interesse_em_carona(remover)
    print("Feito! Nos vemos na próxima!\n")


def main():
    escolha = ''
    id_user = ''
    while escolha != '0':
        escolha = input("\nOlá passageira, o que precisa hoje? \n"
                        " 1 - Cadastro \n"
                        " 2 - Buscar viagem \n"
                        " 3 - Remover Viagem \n"
                        " 0 - Sair\n").strip()
        if escolha != '0':
            if escolha == '1':
                id_user = cadastro()
            elif escolha == '2':
                consulta(id_user)
            else:
                remove_interesse(id_user)
    print("Até a próxima!")


if __name__ == "__main__":
    main()
